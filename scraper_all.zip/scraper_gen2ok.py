from bs4 import BeautifulSoup
import requests
import json

session = requests.Session()

headers = {
    "User-Agent": (
        "Mozilla/5.0 (Linux; Android 13; SM-A325F) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Mobile Safari/537.36"
    ),

    "Accept": (
        "text/html,application/xhtml+xml,"
        "application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
    ),

    "Accept-Language": "en-US,en;q=0.9",

    "Cache-Control": "no-cache",
    "Pragma": "no-cache",

    "Referer": "https://www.google.com/",

    "Upgrade-Insecure-Requests": "1",

    "Connection": "keep-alive"
}

cookies = {
    "device_verified": "true",
    "kt_referer": "https://www.google.com/",
    "PHPSESSID": "ffqtcagcbl1frr47v07kqk3if7"
}

url = "https://pornky.st/"

response = session.get(
    url,
    headers=headers,
    cookies=cookies,
    timeout=60
)

print("STATUS:", response.status_code)
print("HTML LENGTH:", len(response.text))

html = response.text

with open("debug.html", "w", encoding="utf-8") as f:
    f.write(html)

soup = BeautifulSoup(html, "html.parser")

items = soup.select("div.video")

print("FOUND:", len(items))

videos = []
seen = set()

for item in items:

    try:

        a = item.select_one("a[href]")
        img = item.select_one("img")

        if not a:
            continue

        href = a.get("href", "").strip()

        if not href:
            continue

        if href in seen:
            continue

        seen.add(href)

        title = ""

        if img:
            title = (
                img.get("alt")
                or img.get("title")
                or ""
            ).strip()

        if not title:
            title = a.get_text(strip=True)

        poster = ""

        if img:
            poster = (
                img.get("src")
                or img.get("data-src")
                or ""
            ).strip()

        videos.append({
            "title": title,
            "url": href,
            "poster": poster
        })

        print("ADDED:", title)

    except Exception as e:
        print("ERROR:", e)

with open("movies.json", "w", encoding="utf-8") as f:
    json.dump(videos, f, ensure_ascii=False, indent=4)

print("DONE:", len(videos))