import xml.etree.ElementTree as ET
from bs4 import BeautifulSoup
import requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
import json
import time
import urllib.parse
import os
import re

# ---------------------------------------------------------
# DHCP 1: BeautifulSoup দিয়ে মুভির তালিকা স্ক্র্যাপ করা
# ---------------------------------------------------------
session = requests.Session()

headers = {
    "User-Agent": (
        "Mozilla/5.0 (Linux; Android 13; SM-A325F) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Mobile Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.google.com/",
    "Connection": "keep-alive"
}

cookies = {
    "device_verified": "true",
    "kt_referer": "https://www.google.com/",
    "PHPSESSID": "ffqtcagcbl1frr47v07kqk3if7"
}

scraped_movies = []
seen_urls = set()

# পেজ ১ থেকে ২ পর্যন্ত লুপ চালানো হচ্ছে
for page_num in range(1, 3):
    if page_num == 1:
        url = "https://pornky.st/latest-updates/"
    else:
        url = f"https://pornky.st/latest-updates/{page_num}/"

    print(f"Scraping list page {page_num}: {url}")

    try:
        response = session.get(url, headers=headers, cookies=cookies, timeout=60)
        
        if response.status_code != 200:
            print(f"Failed to load page {page_num} - Status: {response.status_code}")
            continue

        soup = BeautifulSoup(response.text, "html.parser")
        items = soup.select("div.video")

        if not items:
            print(f"No items found on page {page_num}. Stopping discovery...")
            break

        for item in items:
            try:
                a = item.select_one("a[href]")
                img = item.select_one("img")

                if not a: 
                    continue
                href = a.get("href", "").strip()
                if not href or href in seen_urls: 
                    continue

                seen_urls.add(href)
                
                title = (img.get("alt") or img.get("title") or a.get_text(strip=True) or "").strip()
                poster = (img.get("src") or img.get("data-src") or "").strip()
                
                if poster.startswith('/'):
                    poster = "https://pornky.st" + poster

                scraped_movies.append({
                    "title": title,
                    "url": href,
                    "poster": poster
                })

            except Exception as item_err:
                print(f"Error packing item: {item_err}")

        time.sleep(1)

    except Exception as page_err:
        print(f"Error crawling page {page_num}: {page_err}")

print(f"\nCataloging Complete. Total Movies Indexed: {len(scraped_movies)}")
print("Transitioning to Deep Traffic Capture...\n")


# ---------------------------------------------------------
# DHCP 2: Selenium দিয়ে ব্যাকগ্রাউন্ড নেটওয়ার্ক ট্রাফিক ট্র্যাকিং
# ---------------------------------------------------------
output_xml_file = r"C:\Users\Habib\Downloads\output_movies.xml"
output_root = ET.Element("movies")

# সেলিনিয়াম ক্রোম ব্রাউজার সেটিংস
chrome_options = Options()
chrome_options.add_argument("--disable-blink-features=AutomationControlled")
chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
chrome_options.add_experimental_option('useAutomationExtension', False)
chrome_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-dev-shm-usage")
chrome_options.add_argument("--remote-debugging-port=9222") 
chrome_options.add_argument(r"--user-data-dir=C:\Users\Habib\Downloads\SeleniumChromeProfile")

chrome_options.add_argument("--start-maximized")
chrome_options.add_argument("--mute-audio") 

# নেটওয়ার্ক ট্রাফিক ট্র্যাকিং অন করা
chrome_options.set_capability('goog:loggingPrefs', {'performance': 'ALL'})

print("--- Launching Anti-Bot Selenium Chrome Instance... ---")

try:
    driver = webdriver.Chrome(options=chrome_options)
    
    # এখানে ভুলটি ঠিক করা হয়েছে (execute_cmd_cmd বদলে execute_cdp_cmd করা হয়েছে)
    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    })
    print("--- Browser Started Successfully! Sniffing live traffic... ---\n")
except Exception as init_err:
    print(f"Failed to initialize the browser: {init_err}")
    print("Please verify via Task Manager that chromedriver.exe is completely closed and try again.")
    exit()

try:
    # প্রতিটি মুভি আইটেমের ওপর লুপ চালানো হচ্ছে
    for index, data in enumerate(scraped_movies, 1):
        title = data["title"]
        video_page_url = data["url"]
        poster_url = data["poster"]
        
        print(f"[{index}/{len(scraped_movies)}] Title: {title}")
        print(f"Page URL: {video_page_url}")
        print(f"Poster URL: {poster_url}")
        
        final_video_link = "No direct MP4 found"
        
        try:
            driver.get(video_page_url)
            time.sleep(10) # ক্লাউডফ্লেয়ার লোড হওয়ার জন্য পর্যাপ্ত সময়
            
            # --- আইফ্রেম (iFrame) চেক এবং হ্যান্ডেল করা ---
            iframes = driver.find_elements(By.TAG_NAME, "iframe")
            if iframes:
                for iframe in iframes:
                    try:
                        driver.switch_to.frame(iframe)
                        video_element = driver.find_element(By.TAG_NAME, "video")
                        driver.execute_script("arguments[0].play();", video_element)
                        break
                    except:
                        driver.switch_to.default_content()

            # --- মেইন পেজে ভিডিও প্লে করার চেষ্টা ---
            driver.switch_to.default_content()
            try:
                video_canvas = driver.find_element(By.TAG_NAME, "video")
                actions = ActionChains(driver)
                actions.move_to_element(video_canvas).click().perform()
            except:
                try:
                    driver.execute_script("document.querySelector('video').play();")
                except:
                    pass

            time.sleep(6) # ভিডিও চালুর পর নেটওয়ার্ক ডাটা আসার জন্য অপেক্ষা
            
            # ব্রাউজারের ব্যাকএন্ড নেটওয়ার্ক লগ সংগ্রহ করা
            logs = driver.get_log("performance")
            clean_links = set()
            
            for entry in logs:
                log = json.loads(entry["message"])["message"]
                if "Network.requestWillBeSent" in log["method"]:
                    params = log.get("params", {})
                    if "request" in params:
                        request_url = params["request"].get("url", "")
                        
                        # ইউআরএল ডিকোড করে ভেতরের আসল ভিডিও লিংক ফিল্টার করা
                        decoded_url = urllib.parse.unquote(request_url)
                        matches = re.findall(r'(https?://[^\s"\']+\.(?:mp4|m3u8)[^\s?&"\']*)', decoded_url, re.IGNORECASE)
                        
                        for match in matches:
                            if not any(x in match for x in ["ping.gif", "get_image", "poster", "analytics", "favicon"]):
                                clean_links.add(match)
            
            if clean_links:
                link_list = list(clean_links)
                final_video_link = link_list[0]
                print(f"Video Link Caught: {final_video_link}")
            else:
                print("Video Links: No direct MP4 found in traffic.")
                
        except Exception as page_error:
            print(f"-> Error parsing video elements: {page_error}")
            final_video_link = f"Error: {str(page_error)}"
            
        # ডেটা এক্সএমএল (XML) নোডে সাজানো হচ্ছে
        movie_node = ET.SubElement(output_root, "movie")
        ET.SubElement(movie_node, "title").text = title
        ET.SubElement(movie_node, "page_url").text = video_page_url
        ET.SubElement(movie_node, "poster_url").text = poster_url
        ET.SubElement(movie_node, "video_url").text = final_video_link
        
        print("-" * 70)
        time.sleep(2)

finally:
    # চূড়ান্ত ফাইলে সেভ করা হচ্ছে
    output_tree = ET.ElementTree(output_root)
    ET.indent(output_tree, space="    ", level=0)
    output_tree.write(output_xml_file, encoding="utf-8", xml_declaration=True)
    
    print(f"\n--- All data written successfully to XML file: {output_xml_file} ---")
    print("--- Processing Finished for All Items. Terminating Browser... ---")
    driver.quit()