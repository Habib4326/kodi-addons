# -*- coding: utf-8 -*-

from flask import Flask, request, jsonify

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

import json
import time
import re
import urllib.parse

app = Flask(__name__)

CHROME = "/data/data/com.termux/files/usr/bin/chromium-browser"
DRIVER = "/data/data/com.termux/files/usr/bin/chromedriver"


class TrafficFilter:

    @staticmethod
    def extract_clean_links(request_url):

        decoded_url = urllib.parse.unquote(request_url)

        matches = re.findall(
            r'(https?://[^\s"\']+\.(?:mp4|m3u8)[^\s"\']*)',
            decoded_url,
            re.IGNORECASE
        )

        valid_links = []

        for match in matches:

            if not any(x in match.lower() for x in [
                "ping.gif",
                "get_image",
                "poster",
                "analytics",
                "favicon",
                "logo",
                "sprite",
                "thumb"
            ]):

                valid_links.append(match)

        return valid_links


def resolve_stream(page_url):

    options = Options()

    options.binary_location = CHROME

    options.add_argument("--headless=new")

    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")

    options.add_argument("--remote-debugging-port=9222")

    options.add_argument("--window-size=1920,1080")

    options.add_argument(
        "--user-agent=Mozilla/5.0 (Linux; Android 13; Mobile)"
    )

    options.add_experimental_option(
        "excludeSwitches",
        ["enable-automation"]
    )

    options.add_experimental_option(
        "useAutomationExtension",
        False
    )

    options.set_capability(
        "goog:loggingPrefs",
        {"performance": "ALL"}
    )

    service = Service(DRIVER)

    driver = webdriver.Chrome(
        service=service,
        options=options
    )

    stream = None

    try:

        print("\nOPEN PAGE:")
        print(page_url)

        driver.get(page_url)

        time.sleep(15)

        logs = driver.get_log("performance")

        for entry in logs:

            try:

                message = json.loads(
                    entry["message"]
                )["message"]

                if (
                    message["method"]
                    == "Network.requestWillBeSent"
                ):

                    req = message["params"]["request"]

                    url = req.get("url", "")

                    print(url)

                    links = TrafficFilter.extract_clean_links(url)

                    if links:

                        stream = links[0]

                        print("\nDIRECT VIDEO SRC FOUND:")
                        print(stream)

                        break

            except Exception:
                pass

    except Exception as e:

        print("\nERROR:")
        print(str(e))

    finally:

        driver.quit()

    return stream


@app.route("/")
def home():

    return "Resolver Running"


@app.route("/resolve")
def resolve():

    url = request.args.get("url")

    if not url:

        return jsonify({
            "status": "error",
            "message": "No URL"
        })

    stream = resolve_stream(url)

    if stream:

        return jsonify({
            "status": "success",
            "stream_url": stream
        })

    return jsonify({
        "status": "error",
        "message": "Stream not found"
    })


if __name__ == "__main__":

    app.run(
        host="0.0.0.0",
        port=8080
    )