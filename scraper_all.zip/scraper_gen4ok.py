from bs4 import BeautifulSoup
import requests
import xml.etree.ElementTree as ET
import time

session = requests.Session()

headers = {
    "User-Agent": (
        "Mozilla/5.0 (Linux; Android 13; SM-A325F) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Mobile Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.google.com/",
    "Connection": "keep-alive"
}

cookies = {
    "device_verified": "true",
    "kt_referer": "https://www.google.com/",
    "PHPSESSID": "ffqtcagcbl1frr47v07kqk3if7"
}

# XML ROOT
root = ET.Element("movies")
seen = set()

# ১ থেকে ২৬৪ পর্যন্ত লুপ
for page_num in range(1, 30):
    # প্রথম পেজের জন্য বেস ইউআরএল, পরের গুলোর জন্য পেজ নাম্বার যোগ হবে
    if page_num == 1:
        url = "https://pornky.st/latest-updates/"
    else:
        url = f"https://pornky.st/latest-updates/{page_num}/"

    print(f"SCRAPING PAGE {page_num}: {url}")

    try:
        response = session.get(url, headers=headers, cookies=cookies, timeout=60)
        
        if response.status_code != 200:
            print(f"FAILED TO LOAD PAGE {page_num} - Status: {response.status_code}")
            continue

        soup = BeautifulSoup(response.text, "html.parser")
        items = soup.select("div.video")

        if not items:
            print(f"NO ITEMS FOUND ON PAGE {page_num}. STOPPING...")
            break

        for item in items:
            try:
                a = item.select_one("a[href]")
                img = item.select_one("img")

                if not a: continue
                href = a.get("href", "").strip()
                if not href or href in seen: continue

                seen.add(href)
                
                title = (img.get("alt") or img.get("title") or a.get_text(strip=True) or "").strip()
                poster = (img.get("src") or img.get("data-src") or "").strip()

                # XML ITEM
                movie = ET.SubElement(root, "movie")
                ET.SubElement(movie, "title").text = title
                ET.SubElement(movie, "url").text = href
                ET.SubElement(movie, "poster").text = poster

            except Exception as e:
                print(f"ERROR IN ITEM: {e}")

        # সার্ভারে অতিরিক্ত চাপ এড়াতে সামান্য বিরতি (ঐচ্ছিক)
        time.sleep(1)

    except Exception as e:
        print(f"ERROR ON PAGE {page_num}: {e}")

# SAVE XML
tree = ET.ElementTree(root)
ET.indent(tree, space="    ", level=0)
tree.write("movies.xml", encoding="utf-8", xml_declaration=True)

print(f"DONE! TOTAL MOVIES FOUND: {len(seen)}")