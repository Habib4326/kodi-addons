from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

CHROME = "/data/data/com.termux/files/usr/bin/chromium-browser"
DRIVER = "/data/data/com.termux/files/usr/bin/chromedriver"

options = Options()

options.binary_location = CHROME

options.add_argument("--headless=new")
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")

service = Service(DRIVER)

driver = webdriver.Chrome(
service=service,
options=options
)

driver.get("https://example.com")

print(driver.title)

driver.quit()
